class ProdutosController < ApplicationController
end
