Rails.application.routes.draw do
  get "produtos", to: "produtos#index"
end
