# Aula 1 - Iniciando o projeto

Curso de Ruby on Rails 5.x

Para executar o projeto após o download, execute no terminal os seguintes comandos:

* bundle install

* rails db:migrate

